import "./Loader.css";

const Loader = () => {
    return (
        // <div className="loading">
        //     <div></div>
        // </div>

<div class="container">
<h4>Bike Doctor</h4>
<div class="wrapper">
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
    <div class="loader">
        <div class="spinner"></div>
    </div>
</div>
</div>
    )
}

export default Loader